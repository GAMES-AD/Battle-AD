/**
 * Mobile Controls for Battle City
 * Adds virtual joystick and enhanced touch controls
 */

class MobileControls {
    constructor() {
        this.joystickActive = false;
        this.joystickCenter = { x: 0, y: 0 };
        this.joystickPosition = { x: 0, y: 0 };
        this.joystickRadius = 50;
        this.deadZone = 0.2;
        
        this.init();
    }

    init() {
        this.createVirtualJoystick();
        this.setupTouchControls();
        this.detectMobileDevice();
    }

    detectMobileDevice() {
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
                         ('ontouchstart' in window) ||
                         (navigator.maxTouchPoints > 0);
        
        if (isMobile) {
            document.body.classList.add('mobile-device');
            this.showMobileControls();
        }
    }

    createVirtualJoystick() {
        // Create joystick container
        const joystickContainer = document.createElement('div');
        joystickContainer.id = 'virtual-joystick';
        joystickContainer.className = 'virtual-joystick';
        
        // Create joystick base
        const joystickBase = document.createElement('div');
        joystickBase.className = 'joystick-base';
        
        // Create joystick stick
        const joystickStick = document.createElement('div');
        joystickStick.className = 'joystick-stick';
        
        joystickBase.appendChild(joystickStick);
        joystickContainer.appendChild(joystickBase);
        
        // Add to mobile controls
        const mobileControls = document.getElementById('mobile-controls');
        if (mobileControls) {
            // Replace D-pad with virtual joystick
            const dPad = mobileControls.querySelector('.d-pad');
            if (dPad) {
                mobileControls.replaceChild(joystickContainer, dPad);
            } else {
                mobileControls.insertBefore(joystickContainer, mobileControls.firstChild);
            }
        }

        this.joystickBase = joystickBase;
        this.joystickStick = joystickStick;
        this.setupJoystickEvents();
    }

    setupJoystickEvents() {
        let isDragging = false;

        const startDrag = (clientX, clientY) => {
            isDragging = true;
            this.joystickActive = true;
            
            const rect = this.joystickBase.getBoundingClientRect();
            this.joystickCenter.x = rect.left + rect.width / 2;
            this.joystickCenter.y = rect.top + rect.height / 2;
            
            this.updateJoystick(clientX, clientY);
        };

        const updateDrag = (clientX, clientY) => {
            if (isDragging) {
                this.updateJoystick(clientX, clientY);
            }
        };

        const endDrag = () => {
            if (isDragging) {
                isDragging = false;
                this.joystickActive = false;
                this.resetJoystick();
                this.clearMovementKeys();
            }
        };

        // Touch events
        this.joystickBase.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            startDrag(touch.clientX, touch.clientY);
        });

        document.addEventListener('touchmove', (e) => {
            if (isDragging) {
                e.preventDefault();
                const touch = e.touches[0];
                updateDrag(touch.clientX, touch.clientY);
            }
        });

        document.addEventListener('touchend', (e) => {
            endDrag();
        });

        // Mouse events for testing on desktop
        this.joystickBase.addEventListener('mousedown', (e) => {
            startDrag(e.clientX, e.clientY);
        });

        document.addEventListener('mousemove', (e) => {
            updateDrag(e.clientX, e.clientY);
        });

        document.addEventListener('mouseup', () => {
            endDrag();
        });
    }

    updateJoystick(clientX, clientY) {
        const deltaX = clientX - this.joystickCenter.x;
        const deltaY = clientY - this.joystickCenter.y;
        const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        
        // Limit stick to joystick radius
        let stickX = deltaX;
        let stickY = deltaY;
        
        if (distance > this.joystickRadius) {
            stickX = (deltaX / distance) * this.joystickRadius;
            stickY = (deltaY / distance) * this.joystickRadius;
        }
        
        // Update stick position
        this.joystickStick.style.transform = `translate(${stickX}px, ${stickY}px)`;
        
        // Calculate normalized position (-1 to 1)
        this.joystickPosition.x = stickX / this.joystickRadius;
        this.joystickPosition.y = stickY / this.joystickRadius;
        
        // Apply dead zone
        if (Math.abs(this.joystickPosition.x) < this.deadZone) this.joystickPosition.x = 0;
        if (Math.abs(this.joystickPosition.y) < this.deadZone) this.joystickPosition.y = 0;
        
        // Convert to keyboard inputs
        this.updateMovementKeys();
    }

    resetJoystick() {
        this.joystickStick.style.transform = 'translate(0px, 0px)';
        this.joystickPosition.x = 0;
        this.joystickPosition.y = 0;
    }

    updateMovementKeys() {
        // Clear previous movement keys
        this.clearMovementKeys();
        
        // Set new movement keys based on joystick position
        const threshold = 0.3;
        
        if (this.joystickPosition.y < -threshold) {
            window.keys = window.keys || {};
            window.keys['ArrowUp'] = true;
        }
        if (this.joystickPosition.y > threshold) {
            window.keys = window.keys || {};
            window.keys['ArrowDown'] = true;
        }
        if (this.joystickPosition.x < -threshold) {
            window.keys = window.keys || {};
            window.keys['ArrowLeft'] = true;
        }
        if (this.joystickPosition.x > threshold) {
            window.keys = window.keys || {};
            window.keys['ArrowRight'] = true;
        }
    }

    clearMovementKeys() {
        if (window.keys) {
            window.keys['ArrowUp'] = false;
            window.keys['ArrowDown'] = false;
            window.keys['ArrowLeft'] = false;
            window.keys['ArrowRight'] = false;
        }
    }

    setupTouchControls() {
        // Enhanced fire button
        const fireButton = document.getElementById('btn-shoot');
        if (fireButton) {
            // Remove existing event listeners and add new ones
            fireButton.replaceWith(fireButton.cloneNode(true));
            const newFireButton = document.getElementById('btn-shoot');
            
            const startShooting = (e) => {
                e.preventDefault();
                window.keys = window.keys || {};
                window.keys['Space'] = true;
            };
            
            const stopShooting = (e) => {
                e.preventDefault();
                if (window.keys) {
                    window.keys['Space'] = false;
                }
            };
            
            newFireButton.addEventListener('touchstart', startShooting);
            newFireButton.addEventListener('touchend', stopShooting);
            newFireButton.addEventListener('mousedown', startShooting);
            newFireButton.addEventListener('mouseup', stopShooting);
            newFireButton.addEventListener('mouseleave', stopShooting);
        }

        // Add haptic feedback if available
        this.setupHapticFeedback();
    }

    setupHapticFeedback() {
        if ('vibrate' in navigator) {
            const fireButton = document.getElementById('btn-shoot');
            if (fireButton) {
                fireButton.addEventListener('touchstart', () => {
                    navigator.vibrate(50); // Short vibration
                });
            }
        }
    }

    showMobileControls() {
        const mobileControls = document.getElementById('mobile-controls');
        if (mobileControls) {
            mobileControls.style.display = 'flex';
        }
    }

    hideMobileControls() {
        const mobileControls = document.getElementById('mobile-controls');
        if (mobileControls) {
            mobileControls.style.display = 'none';
        }
    }

    // Public method to get joystick state (for game integration if needed)
    getJoystickState() {
        return {
            active: this.joystickActive,
            x: this.joystickPosition.x,
            y: this.joystickPosition.y
        };
    }
}

// Initialize mobile controls when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.mobileControls = new MobileControls();
});

// Also initialize if script is loaded after DOM
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.mobileControls = new MobileControls();
    });
} else {
    window.mobileControls = new MobileControls();
}