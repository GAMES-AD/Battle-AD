/**
 * Battle City - WebSocket Server for Online Multiplayer
 * Server-authoritative multiplayer with position and shot synchronization
 */

const WebSocket = require('ws');
const http = require('http');

const PORT = process.env.PORT || 8080;

// Game state management
class GameRoom {
    constructor(id) {
        this.id = id;
        this.players = new Map();
        this.bullets = [];
        this.enemies = [];
        this.gameState = {
            wave: 1,
            enemiesRemaining: 0,
            baseAlive: true
        };
        this.maxPlayers = 4;
        this.gameStarted = false;
        this.lastUpdate = Date.now();
        this.updateInterval = null;
    }

    addPlayer(ws, playerId) {
        if (this.players.size >= this.maxPlayers) {
            return false;
        }

        const playerNumber = this.players.size + 1;
        const player = {
            id: playerId,
            ws: ws,
            playerNumber: playerNumber,
            x: 100 + (playerNumber - 1) * 50,
            y: 500,
            angle: 0,
            lives: 3,
            score: 0,
            active: true,
            lastUpdate: Date.now()
        };

        this.players.set(playerId, player);
        
        // Send initial game state to new player
        this.sendToPlayer(playerId, {
            type: 'player_joined',
            playerId: playerId,
            playerNumber: playerNumber,
            roomId: this.id,
            players: this.getPlayersData(),
            gameState: this.gameState
        });

        // Notify other players
        this.broadcast({
            type: 'player_joined_room',
            playerId: playerId,
            playerNumber: playerNumber,
            playerData: this.getPlayerData(playerId)
        }, playerId);

        console.log(`Player ${playerId} joined room ${this.id} as P${playerNumber}`);

        // Start game if we have players and game hasn't started
        if (this.players.size >= 1 && !this.gameStarted) {
            this.startGame();
        }

        return true;
    }

    removePlayer(playerId) {
        const player = this.players.get(playerId);
        if (!player) return;

        this.players.delete(playerId);

        // Notify remaining players
        this.broadcast({
            type: 'player_left',
            playerId: playerId
        });

        console.log(`Player ${playerId} left room ${this.id}`);

        // Stop game if no players left
        if (this.players.size === 0) {
            this.stopGame();
        }
    }

    updatePlayer(playerId, playerData) {
        const player = this.players.get(playerId);
        if (!player) return;

        // Update player position and state
        player.x = playerData.x;
        player.y = playerData.y;
        player.angle = playerData.angle;
        player.lives = playerData.lives;
        player.score = playerData.score;
        player.lastUpdate = Date.now();

        // Broadcast to other players
        this.broadcast({
            type: 'player_update',
            playerId: playerId,
            playerData: this.getPlayerData(playerId)
        }, playerId);
    }

    addBullet(playerId, bulletData) {
        const bullet = {
            id: `${playerId}_${Date.now()}_${Math.random()}`,
            playerId: playerId,
            x: bulletData.x,
            y: bulletData.y,
            angle: bulletData.angle,
            speed: 450,
            ownerType: 'player',
            active: true,
            timestamp: Date.now()
        };

        this.bullets.push(bullet);

        // Broadcast bullet to all players
        this.broadcast({
            type: 'bullet_fired',
            bullet: bullet
        });
    }

    updateEnemies(enemiesData) {
        this.enemies = enemiesData;
        this.gameState.enemiesRemaining = this.enemies.filter(e => e.active).length;

        // Broadcast enemy state to all players
        this.broadcast({
            type: 'enemies_update',
            enemies: this.enemies,
            gameState: this.gameState
        });
    }

    startGame() {
        this.gameStarted = true;
        this.gameState.wave = 1;
        this.gameState.baseAlive = true;

        // Start server update loop
        this.updateInterval = setInterval(() => {
            this.serverUpdate();
        }, 1000 / 60); // 60 FPS

        this.broadcast({
            type: 'game_started',
            gameState: this.gameState
        });

        console.log(`Game started in room ${this.id}`);
    }

    stopGame() {
        this.gameStarted = false;
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }

        this.broadcast({
            type: 'game_stopped'
        });

        console.log(`Game stopped in room ${this.id}`);
    }

    serverUpdate() {
        const now = Date.now();
        const dt = (now - this.lastUpdate) / 1000;
        this.lastUpdate = now;

        // Update bullets
        this.bullets = this.bullets.filter(bullet => {
            if (!bullet.active) return false;
            
            // Move bullet
            const rad = bullet.angle * Math.PI / 180;
            bullet.x += Math.sin(rad) * bullet.speed * dt;
            bullet.y -= Math.cos(rad) * bullet.speed * dt;

            // Check bounds
            if (bullet.x < 0 || bullet.x > 800 || bullet.y < 0 || bullet.y > 600) {
                bullet.active = false;
                return false;
            }

            // Remove old bullets
            if (now - bullet.timestamp > 5000) {
                bullet.active = false;
                return false;
            }

            return true;
        });

        // Send periodic sync to all players
        if (now % 100 < 16) { // Every ~100ms
            this.broadcast({
                type: 'sync_update',
                bullets: this.bullets,
                gameState: this.gameState,
                timestamp: now
            });
        }
    }

    getPlayerData(playerId) {
        const player = this.players.get(playerId);
        if (!player) return null;

        return {
            id: player.id,
            playerNumber: player.playerNumber,
            x: player.x,
            y: player.y,
            angle: player.angle,
            lives: player.lives,
            score: player.score,
            active: player.active
        };
    }

    getPlayersData() {
        const playersData = {};
        this.players.forEach((player, id) => {
            playersData[id] = this.getPlayerData(id);
        });
        return playersData;
    }

    sendToPlayer(playerId, message) {
        const player = this.players.get(playerId);
        if (player && player.ws.readyState === WebSocket.OPEN) {
            player.ws.send(JSON.stringify(message));
        }
    }

    broadcast(message, excludePlayerId = null) {
        const messageStr = JSON.stringify(message);
        this.players.forEach((player, playerId) => {
            if (playerId !== excludePlayerId && player.ws.readyState === WebSocket.OPEN) {
                player.ws.send(messageStr);
            }
        });
    }

    isEmpty() {
        return this.players.size === 0;
    }
}

// Server state
const rooms = new Map();
const players = new Map();

// Create WebSocket server
const wss = new WebSocket.Server({ port: PORT });

console.log(`🎮 Battle City WebSocket Server running on port ${PORT}`);

wss.on('connection', (ws) => {
    let playerId = null;
    let roomId = null;

    console.log('New WebSocket connection');

    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);
            
            switch(data.type) {
                case 'join_game':
                    playerId = generatePlayerId();
                    roomId = findOrCreateRoom();
                    
                    const room = rooms.get(roomId);
                    if (room.addPlayer(ws, playerId)) {
                        players.set(playerId, { ws, roomId });
                    } else {
                        ws.send(JSON.stringify({
                            type: 'error',
                            message: 'Room is full'
                        }));
                    }
                    break;

                case 'player_update':
                    if (playerId && roomId) {
                        const room = rooms.get(roomId);
                        if (room) {
                            room.updatePlayer(playerId, data.playerData);
                        }
                    }
                    break;

                case 'bullet_fired':
                    if (playerId && roomId) {
                        const room = rooms.get(roomId);
                        if (room) {
                            room.addBullet(playerId, data.bulletData);
                        }
                    }
                    break;

                case 'enemies_update':
                    if (playerId && roomId) {
                        const room = rooms.get(roomId);
                        if (room) {
                            room.updateEnemies(data.enemies);
                        }
                    }
                    break;

                case 'ping':
                    ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
                    break;
            }
        } catch (error) {
            console.error('Error processing message:', error);
        }
    });

    ws.on('close', () => {
        console.log('WebSocket connection closed');
        
        if (playerId && roomId) {
            const room = rooms.get(roomId);
            if (room) {
                room.removePlayer(playerId);
                
                // Clean up empty rooms
                if (room.isEmpty()) {
                    rooms.delete(roomId);
                    console.log(`Room ${roomId} deleted (empty)`);
                }
            }
            
            players.delete(playerId);
        }
    });

    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
    });
});

function generatePlayerId() {
    return 'player_' + Math.random().toString(36).substr(2, 9);
}

function findOrCreateRoom() {
    // Find a room with available slots
    for (const [id, room] of rooms) {
        if (room.players.size < room.maxPlayers && !room.gameStarted) {
            return id;
        }
    }
    
    // Create new room
    const roomId = 'room_' + Math.random().toString(36).substr(2, 9);
    rooms.set(roomId, new GameRoom(roomId));
    console.log(`Created new room: ${roomId}`);
    return roomId;
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server...');
    wss.close();
    process.exit(0);
});

// Server stats
setInterval(() => {
    console.log(`📊 Stats: ${rooms.size} rooms, ${players.size} players`);
}, 30000);