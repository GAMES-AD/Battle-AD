# 🎮 Modern Battle City — Browser Game (Online & Co-op)

**Modern Battle City** is a modern 2D browser remake of the classic *Battle City*, built with **HTML5 Canvas and Vanilla JavaScript**.  
The game supports **singleplayer, local co-op, online multiplayer, and mobile touch controls**.

---

## 🚀 Features

### 🎯 Core Gameplay
- Top-down 2D action
- Tile-based map system
- Destructible and indestructible walls
- Player base defense (base destroyed = Game Over)
- Enemy waves with increasing difficulty
- Score, lives, and progression system

### 👥 Game Modes
- **Singleplayer**
- **Local Co-op (2 players on one device)**
- **Online Multiplayer (2–4 players)** via WebSocket

### 🤖 Enemy AI
- Finite State Machine (FSM)
- States:
  - SPAWN
  - PATROL
  - SEEK_PLAYER
  - SEEK_BASE
  - ATTACK
  - EVADE
  - RETREAT
- Enemy types:
  - Scout (fast)
  - Soldier (standard)
  - Tank (armored)
  - Elite (advanced AI)

### 🎁 Power-ups
- Shield
- Rapid Fire
- Double Damage
- Freeze Enemies
- Extra Life
- Revive Ally
- Air Strike

### 📱 Mobile Support
- Virtual joystick
- Fire button
- Touch controls
- Responsive UI
- Fullscreen mode

### 🔊 Audio & Effects
- Web Audio API
- Shooting, explosion, bonus sounds
- Background music
- Volume control and mute
- Screen shake, particles, glow effects

---

## 🛠️ Tech Stack

- HTML5
- CSS3
- Vanilla JavaScript (ES6+)
- Canvas 2D
- WebSocket (online multiplayer)
- Web Audio API
- requestAnimationFrame
- Node.js (server)

❌ No Phaser, Unity, Three.js, React

---

## 📁 Project Structure

