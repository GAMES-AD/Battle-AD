#!/bin/bash

echo "🎮 Starting Battle City Multiplayer Server..."
echo ""
echo "Installing dependencies..."
npm install
echo ""
echo "Starting WebSocket server on port 8080..."
echo "Players can connect by pressing 'O' in the game menu"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
node server.js